using System;
using System.Collections.Generic;
class Program
{
    static void Main(string[] args)
    {
        int vidas = 6;
        string respuesta;
        bool acierto;
        List <string> palabras = new List<string>()
        {
            "Karma","LastBreath","Hardmode","Betrayer","Gaster","Ainvol","Agem"
        };
        Random random = new Random();
        bool valio_cola = false;
        int seleccion = random.Next(palabras.Count);
        string palabra = palabras[seleccion].ToUpper();
        string [] invisible = new string [palabra.Length];
        List <string> disponibles = new List <string>();
        for (int i = 0; i < palabra.Length; i++)
        {
            invisible[i] = "?";
        }
           Console.WriteLine("Bienvenido a el juego del ahorcado.");
        while (vidas > 0 && !valio_cola)
        {
            Console.WriteLine("Adivina la palabra correcta antes que se te acaben las vidas.");
            respuesta = Console.ReadLine();
            if (disponibles.Contains(respuesta)){
                Console.WriteLine("Ya utilizaste esa letra.");
            }else{
                disponibles.Add(respuesta);
            }
            foreach(string Letra in invisible){
                Console.WriteLine(Letra + "");
            }
            acierto = false;
            for (int i = 0; i < palabra.Length; i++){
                if (palabra[i].ToString() == respuesta){
                    invisible[i] = respuesta;
                    acierto = true;
                }
            }
            if(!acierto){
                vidas --;
                Console.WriteLine("La Letra no es correcta");
            }
            valio_cola = true;
            for(int i = 0; i < invisible.Length; i++){
                if(invisible[i] == "?"){
                    valio_cola = false;
                    break;
                }
            }
        }
        if (vidas <= 0)
        {
            Console.WriteLine("Perdiste");
            Console.WriteLine("La palabra era " + palabra);
        }
        else
        {
            Console.WriteLine("Ganaste");
            Console.WriteLine("La palabra era " + palabra);
        }
        
        Console.WriteLine("\nVidas finales: " + vidas);
    }
}