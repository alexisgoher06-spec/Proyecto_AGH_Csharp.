using System;
using System.Collections.Generic;
namespace Cuidado;

class Program
{
    static void Main(string[] args)
    {
        int opcion;
        List<string> productos = new List<string>();
        do{
            Console.WriteLine("====Lista de Compras====");
            Console.WriteLine("1.Agregar Producto");
            Console.WriteLine("2.Mostrar Productos");
            Console.WriteLine("3.Buscar Productos");
            Console.WriteLine("4.Eliminar productos");
            Console.WriteLine("5.Nostrar Cantidad de producto");
            Console.WriteLine("6.Salir");
            Console.WriteLine("Elige una opcion");
            opcion = int.Parse(Console.ReadLine());
            switch(opcion){
                case 1:
                Console.WriteLine("Ingresa un producto");
                string producto = Console.ReadLine();
                productos.Add(producto);
                break;
                case 2:
                Console.WriteLine("Tus productos");
                for(int i = 0 ; i < productos.Count ; i ++){
                    Console.WriteLine("Los productos son: " + productos[i]);
                }
                break;
                case 3:
                Console.WriteLine("Que producto estas buscando?");
                string Buscar = Console.ReadLine();
                if(productos.Contains(Buscar)){
                    int posicion = productos.IndexOf(Buscar);
                    Console.WriteLine("El producto esta en la Lista, se encuentra en la posicion " + posicion);
                }else{
                    Console.WriteLine("El producto no se encuentra");
                }
                break;
                case 4:
                Console.WriteLine("Que elemento deseas eliminar");
                string Eliminar = Console.ReadLine();
                if(productos.Contains(Eliminar))
                {
                    productos.Remove(Eliminar);
                    Console.WriteLine("Objeto Eliminado");
                }else{
                    Console.WriteLine("No se elimino");
                }
                break;
                case 5:
                Console.WriteLine("Total de productos" + productos.Count);
                break;
                default:
                Console.WriteLine("invalido");
                break;
            }
        }while( opcion != 6);
    }
}